import React from 'react';



const Contact = (props) => {
    return (
        <div >
            <center>
                <h1>Contact</h1>
                <h2>support@WDA.com</h2>
            </center>

        </div>
    )
}

export default Contact;